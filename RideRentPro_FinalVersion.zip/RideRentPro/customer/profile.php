<?php
session_start();
if (!isset($_SESSION['customer_id'])) {
    header("Location: ../auth/login.php");
    exit();
}
require_once __DIR__ . '/../config/database.php';

$customer_id = $_SESSION['customer_id'];

// Handle profile update
if(isset($_POST['update_profile'])) {
    $full_name = mysqli_real_escape_string($conn, $_POST['full_name']);
    $phone_1 = mysqli_real_escape_string($conn, $_POST['phone_1']);
    $phone_2 = mysqli_real_escape_string($conn, $_POST['phone_2']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    
    // Handle image upload
    if(!empty($_FILES['profile_image']['name'])) {
        $image_name = $_FILES['profile_image']['name'];
        $tmp_name = $_FILES['profile_image']['tmp_name'];
        $extension = strtolower(pathinfo($image_name, PATHINFO_EXTENSION));
        $allowed = array("jpg", "jpeg", "png");
        
        if(in_array($extension, $allowed)) {
            $new_image = time()."_".$image_name;
            move_uploaded_file($tmp_name, "../assets/uploads/".$new_image);
            mysqli_query($conn, "UPDATE customer SET profile_image = '$new_image' WHERE customer_id = '$customer_id'");
        }
    }
    
    mysqli_query($conn, "UPDATE customer SET full_name = '$full_name', phone_1 = '$phone_1', phone_2 = '$phone_2', address = '$address' WHERE customer_id = '$customer_id'");
    header("Location: profile.php");
    exit();
}

$customerInfo = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM customer WHERE customer_id = '$customer_id'"));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - RideRent Pro</title>
    <link rel="stylesheet" href="../assets/css/new-theme.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<script src="../assets/js/theme.js"></script>

<!-- Dashboard Container -->
<div class="dashboard-container">
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h2><i class="fas fa-car-side"></i> RideRent Pro</h2>
        </div>
        <div class="sidebar-nav">
            <ul>
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="vehicles.php"><i class="fas fa-car"></i> Browse Vehicles</a></li>
                <li><a href="bookings.php"><i class="fas fa-calendar-check"></i> My Bookings</a></li>
                <li><a href="profile.php" class="active"><i class="fas fa-user"></i> My Profile</a></li>
                <li><a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </div>
        <div class="sidebar-footer">
            <button class="theme-toggle" onclick="toggleTheme()" style="width: 100%; justify-content: center;">
                <i class="fas fa-moon"></i>
                <span>Dark Mode</span>
            </button>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="page-header">
            <h1><i class="fas fa-user"></i> My Profile</h1>
            <p>View and update your profile information</p>
        </div>

        <div class="card">
            <div class="card-body" style="display: grid; grid-template-columns: 1fr 2fr; gap: 40px;">
                <div style="text-align: center;">
                    <?php if(!empty($customerInfo['profile_image'])) { ?>
                        <img src="../assets/uploads/<?php echo $customerInfo['profile_image']; ?>" style="width: 150px; height: 150px; border-radius: 50%; object-fit: cover; margin-bottom: 20px;">
                    <?php } else { ?>
                        <img src="https://via.placeholder.com/150x150?text=Customer" style="width: 150px; height: 150px; border-radius: 50%; object-fit: cover; margin-bottom: 20px;">
                    <?php } ?>
                    <h3><?php echo $customerInfo['full_name']; ?></h3>
                    <p style="color: var(--medium-gray);"><?php echo $customerInfo['email']; ?></p>
                    <p><span class="badge badge-success"><?php echo $customerInfo['status']; ?></span></p>
                </div>
                <div>
                    <table style="width: 100%; margin-top: 20px;">
                        <tr>
                            <th style="width: 30%; padding: 12px; background: var(--off-white); color: var(--dark-gray); font-weight: 600;">Customer ID</th>
                            <td style="padding: 12px; color: var(--dark-gray);"><?php echo $customerInfo['customer_id']; ?></td>
                        </tr>
                        <tr>
                            <th style="padding: 12px; background: var(--off-white); color: var(--dark-gray); font-weight: 600;">Username</th>
                            <td style="padding: 12px; color: var(--dark-gray);"><?php echo $customerInfo['username']; ?></td>
                        </tr>
                        <tr>
                            <th style="padding: 12px; background: var(--off-white); color: var(--dark-gray); font-weight: 600;">Email</th>
                            <td style="padding: 12px; color: var(--dark-gray);"><?php echo $customerInfo['email']; ?></td>
                        </tr>
                        <tr>
                            <th style="padding: 12px; background: var(--off-white); color: var(--dark-gray); font-weight: 600;">Primary Phone</th>
                            <td style="padding: 12px; color: var(--dark-gray);"><?php echo $customerInfo['phone_1']; ?></td>
                        </tr>
                        <tr>
                            <th style="padding: 12px; background: var(--off-white); color: var(--dark-gray); font-weight: 600;">Secondary Phone</th>
                            <td style="padding: 12px; color: var(--dark-gray);"><?php echo $customerInfo['phone_2'] ? $customerInfo['phone_2'] : 'N/A'; ?></td>
                        </tr>
                        <tr>
                            <th style="padding: 12px; background: var(--off-white); color: var(--dark-gray); font-weight: 600;">NID Number</th>
                            <td style="padding: 12px; color: var(--dark-gray);"><?php echo $customerInfo['nid_number'] ? $customerInfo['nid_number'] : 'N/A'; ?></td>
                        </tr>
                        <tr>
                            <th style="padding: 12px; background: var(--off-white); color: var(--dark-gray); font-weight: 600;">Address</th>
                            <td style="padding: 12px; color: var(--dark-gray);"><?php echo $customerInfo['address'] ? $customerInfo['address'] : 'N/A'; ?></td>
                        </tr>
                        <tr>
                            <th style="padding: 12px; background: var(--off-white); color: var(--dark-gray); font-weight: 600;">Member Since</th>
                            <td style="padding: 12px; color: var(--dark-gray);"><?php echo date('F j, Y', strtotime($customerInfo['created_at'])); ?></td>
                        </tr>
                    </table>
                    
                    <hr style="margin: 30px 0;">
                    
                    <h4>Update Profile</h4>
                    <form method="POST" enctype="multipart/form-data" style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                        <div class="form-group">
                            <label class="form-label">Full Name</label>
                            <input type="text" name="full_name" class="form-control" value="<?php echo $customerInfo['full_name']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Primary Phone</label>
                            <input type="text" name="phone_1" class="form-control" value="<?php echo $customerInfo['phone_1']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Secondary Phone</label>
                            <input type="text" name="phone_2" class="form-control" value="<?php echo $customerInfo['phone_2']; ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Address</label>
                            <input type="text" name="address" class="form-control" value="<?php echo $customerInfo['address']; ?>">
                        </div>
                        <div class="form-group" style="grid-column: span 2;">
                            <label class="form-label">Profile Image</label>
                            <input type="file" name="profile_image" class="form-control">
                        </div>
                        <div style="grid-column: span 2;">
                            <button type="submit" name="update_profile" class="btn btn-primary">Update Profile</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>